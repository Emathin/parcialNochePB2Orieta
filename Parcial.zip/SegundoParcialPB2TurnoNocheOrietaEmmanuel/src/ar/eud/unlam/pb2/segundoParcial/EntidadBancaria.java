package ar.eud.unlam.pb2.segundoParcial;

import java.util.HashSet;
import java.util.Set;

public class EntidadBancaria {
	
	private String nombre;
	private Set<Cliente> ConjuntoClientes;
	private Set<Transaccion> ConjuntoDeTransacciones;
	
	public Set<Transaccion> getConjuntoDeTransacciones() {
		return ConjuntoDeTransacciones;
	}

	public EntidadBancaria(String nombreEntidadBancaria) {
		this.nombre = nombreEntidadBancaria;
		this.ConjuntoClientes=new HashSet<>();
		this.ConjuntoDeTransacciones=new HashSet<>();
	}

	public void agregarCliente(Cliente cliente) {
		ConjuntoClientes.add(cliente);
	}
	
	public void agregarTransaccion(Transaccion transaccion) {
		this.ConjuntoDeTransacciones.add(transaccion);
	}
	
	

}
