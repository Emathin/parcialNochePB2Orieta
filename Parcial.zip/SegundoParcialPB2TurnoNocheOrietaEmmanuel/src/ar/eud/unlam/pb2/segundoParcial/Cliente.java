package ar.eud.unlam.pb2.segundoParcial;

import java.util.HashSet;
import java.util.Set;

public class Cliente {

	private Integer cuit;
	private String nombre;
	private Set<Pc> conjuntoDispositivos;
	private Boolean cambioRecienteDeContrase�a;
	private Integer fondosCliente;


	public Cliente(Integer cuit, String nombre,Pc dispositivo) {
		this.cuit = cuit;
		this.nombre = nombre;
		this.conjuntoDispositivos=new HashSet<>();
		this.cambioRecienteDeContrase�a=true;
		this.fondosCliente=3000;
	}

	public Integer getCuit() {
		return cuit;
	}

	public String getNombre() {
		return nombre;
	}

	public void agregarDispositivo(Pc dispositivoDelCliente) {
		this.conjuntoDispositivos.add(dispositivoDelCliente);
	}

	public Boolean getCambioRecienteDeContrase�a() {
		return cambioRecienteDeContrase�a;
	}

	public Integer getFondosCliente() {
		return fondosCliente;
	}

	
}
