package ar.eud.unlam.pb2.segundoParcial;

public class ConsultaUsuario implements Monitoreable, Rechazable {

	@Override
	public Boolean monitorear() throws FraudeException {
		// TODO Auto-generated method stub
		return null;
	}

}
