package ar.eud.unlam.pb2.segundoParcial;

public interface Alertable {
	public void marcarComoCasoSospechoso();
	public void confirmarSiFueFraude(Boolean fueFraude);
}
