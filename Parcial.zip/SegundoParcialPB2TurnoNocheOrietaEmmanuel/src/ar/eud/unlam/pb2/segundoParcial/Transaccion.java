package ar.eud.unlam.pb2.segundoParcial;

public abstract class Transaccion {

	private Integer idTransaccion;

	public Transaccion(Integer id) {
		this.idTransaccion=id;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((idTransaccion == null) ? 0 : idTransaccion.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Transaccion other = (Transaccion) obj;
		if (idTransaccion == null) {
			if (other.idTransaccion != null)
				return false;
		} else if (!idTransaccion.equals(other.idTransaccion))
			return false;
		return true;
	}
	
	
}
