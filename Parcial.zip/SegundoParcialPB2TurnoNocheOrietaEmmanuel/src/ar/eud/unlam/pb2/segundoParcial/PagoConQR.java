package ar.eud.unlam.pb2.segundoParcial;

public class PagoConQR extends Monetaria implements Rechazable, Monitoreable {

	@Override
	public Boolean monitorear() {
		// TODO Auto-generated method stub
		
	}

}
