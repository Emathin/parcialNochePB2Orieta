package ar.eud.unlam.pb2.segundoParcial;

public class Movil extends Pc {

	private Integer IMEI;
	

	private String tipoDeRegistro;

	public Movil(String SO, Integer ip, String localidad,Integer macAdress, Integer IMEI, String tipoDeRegistro) {
		super(SO, ip, localidad, macAdress);
		this.IMEI = IMEI;
		this.tipoDeRegistro = tipoDeRegistro;

	}

	public Integer getIMEI() {
		return IMEI;
	}

	public String getTipoDeRegistro() {
		return tipoDeRegistro;
	}
}
