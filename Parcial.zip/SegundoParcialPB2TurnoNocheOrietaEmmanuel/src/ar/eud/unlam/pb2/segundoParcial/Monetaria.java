package ar.eud.unlam.pb2.segundoParcial;

import java.util.List;

public abstract class Monetaria extends Transaccion {

	
	public Monetaria(Integer id) {
		super(id);
	}

	public Boolean monitorear() {
		// TODO Auto-generated method stub
		return null;
	}

	public Boolean monitorear(List<Integer> listaNegra, Cliente cliente, Pc dispositivo, List<Integer> listaNegraIPOIME)
			throws FraudeException {
		// TODO Auto-generated method stub
		return null;
	}

}
