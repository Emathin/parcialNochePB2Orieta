package ar.eud.unlam.pb2.segundoParcial;

public class Pc{
	private String SO;
	private Integer ip;
	private String localidad;
	private Integer macAdress;
	
	public Pc(String SO, Integer  ip, String localidad,Integer macAdress) {
		this.SO=SO;
		this.ip=ip;
		this.localidad=localidad;
		this.macAdress=macAdress;
	}

	public String getSO() {
		return SO;
	}

	public Integer getIp() {
		return ip;
	}

	public String getLocalidad() {
		return localidad;
	}

	public Integer getMacAdress() {
		return macAdress;
	}
	
	

}
