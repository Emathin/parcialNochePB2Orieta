package ar.eud.unlam.pb2.segundoParcial;

public class AltaUsuario extends NoMonetaria implements Monitoreable, Rechazable {

	@Override
	public Boolean monitorear() {
		// TODO Auto-generated method stub
		return null;
	}

}
