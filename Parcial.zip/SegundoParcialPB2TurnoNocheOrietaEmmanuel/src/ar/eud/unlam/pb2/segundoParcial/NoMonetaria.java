package ar.eud.unlam.pb2.segundoParcial;

public abstract class NoMonetaria extends Transaccion {

}
