package ar.eud.unlam.pb2.segundoParcial;

public interface Denunciable {

}
