package ar.eud.unlam.pb2.segundoParcial;

import java.util.List;

public class Extraccion extends Monetaria implements Rechazable, Monitoreable {
	private Integer id;
	private Integer monto;
	private Boolean bloqueada;

	public Extraccion(Integer id, Integer monto, Cliente cliente, Pc dispositivo, List<Integer> listaNegra,
			List<Integer> listaNegraIPOIME, EntidadBancaria nuevaEntidad) throws FraudeException {
		super(id);
		this.monto = monto;
		this.bloqueada = false;
		monitorear(listaNegra, cliente, dispositivo, listaNegraIPOIME,nuevaEntidad);
	}

	@Override
	public Boolean monitorear(List<Integer> listaNegra, Cliente cliente, Pc dispositivo, List<Integer> listaNegraIPOIME,EntidadBancaria nuevaEntidad)
			throws FraudeException {

		Integer score = 0;

		if (listaNegra.contains(cliente.getCuit())) {
			bloqueada = true;
			score += 80;

		}

		if (listaNegraIPOIME.contains(dispositivo.getIp())) {
			score += 80;
		}

		if (cliente.getCambioRecienteDeContrase�a() == true) {
			score += 20;
		}

		if (cliente.getFondosCliente() == monto) {
			score += 40;
		}

		if (nuevaEntidad.getConjuntoDeTransacciones().== true) {
			score += 20;
		}

		if (score >= 80) {
			throw new FraudeException();
		}
		return true;

	}

	@Override
	public Boolean monitorear() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Extraccion other = (Extraccion) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}

	@Override
	public Boolean monitorear(List<Integer> listaNegra, Cliente cliente) throws FraudeException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Boolean monitorear(List<Integer> listaNegra, Cliente cliente, List<Integer> listaNegraIPOIME)
			throws FraudeException {
		// TODO Auto-generated method stub
		return null;
	}

}
