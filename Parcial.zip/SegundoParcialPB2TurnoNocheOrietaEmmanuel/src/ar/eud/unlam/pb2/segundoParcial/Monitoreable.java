package ar.eud.unlam.pb2.segundoParcial;

import java.util.List;

public interface Monitoreable {
	
	public Boolean monitorear();
}
