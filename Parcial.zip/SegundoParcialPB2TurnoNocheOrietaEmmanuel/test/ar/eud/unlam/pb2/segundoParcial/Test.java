package ar.eud.unlam.pb2.segundoParcial;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

public class Test {

	@org.junit.Test
	public void queSePuedaCrearUnCliente() {

		Pc nuevoDispositivo1 = new Pc("Windows", 111555, "san Justo", (Integer) 111222);
		Cliente nuevoCliente = new Cliente((Integer) 30 - 34409322 - 9, "Emmanuel", nuevoDispositivo1);

	}

	@org.junit.Test
	public void queSePuedaCrearUnDispositivo() {

		Pc nuevoDispositivo1 = new Pc("Windows", 111555, "san Justo", (Integer) 111222);
		Pc nuevoDispositivo2 = new Movil("Windows", 111555, "san Justo", (Integer) 111555, 123456789,
				"biometria");
	}

	@org.junit.Test(expected = FraudeException.class)
	public void queSePuedaMonitorearUnaExtraccion() throws FraudeException {

		List<Integer> listaNegraCUITS = new ArrayList<>();
		listaNegraCUITS.add(2849179);
		listaNegraCUITS.add(30344077);// Cuit cliente
		listaNegraCUITS.add(654564);

		List<Integer> listaNegraIPOIME = new ArrayList<>();
		listaNegraIPOIME.add(2849179);
		listaNegraIPOIME.add(111555);//IP dispositivo
		listaNegraIPOIME.add(654564);

		Pc nuevoDispositivo2 = new Pc("Windows", 111555, "san Justo", (Integer) 111555);
		EntidadBancaria nuevaEntidad = new EntidadBancaria("El Ciudad");
		Cliente nuevoCliente = new Cliente((Integer) 30344077, "Emmanuel", nuevoDispositivo2);
		Monetaria extraccion1 = new Extraccion(1, 3000, nuevoCliente, nuevoDispositivo2, listaNegraCUITS,
				listaNegraIPOIME,nuevaEntidad);
		nuevaEntidad.agregarTransaccion(extraccion1);
	}
	/*
	 * @org.junit.Test(expected = FraudeException.class) public void
	 * queSePuedaMonitorearUnPagoConQR() throws FraudeException {
	 * 
	 * List<Integer> listaNegra=new ArrayList<>(); listaNegra.add(2849179);
	 * listaNegra.add(30344077);//Cuit cliente listaNegra.add(654564);
	 * 
	 * Pc nuevoDispositivo2 = new Movil("Windows", "192.168.1.50", "san Justo",
	 * (Integer) 111555, 123456789, "biometria"); EntidadBancaria nuevaEntidad = new
	 * EntidadBancaria("El Ciudad"); Cliente nuevoCliente = new
	 * Cliente((Integer)30344077, "Emmanuel",nuevoDispositivo2); Monetaria pagoQR =
	 * new PagoConQR(1, 3000, nuevoCliente,listaNegra);
	 * nuevaEntidad.agregarTransaccion(extraccion1); }
	 * 
	 */

}
